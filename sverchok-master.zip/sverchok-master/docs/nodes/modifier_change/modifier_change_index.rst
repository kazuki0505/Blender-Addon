***************
Modifier Change
***************

.. toctree::
   :maxdepth: 2

   bevel
   subdivide_mk2
   subdivide_lite
   unsubdivide
   smooth
   relax_mesh
   delete_loose
   mesh_clean
   edges_intersect_mk2
   poke
   extrude_edges_mk2
   extrude_separate
   extrude_separate_lite
   extrude_region
   holes_fill
   flip_normals
   merge_by_distance
   mesh_join_mk2
   mesh_separate
   objects_along_edge
   offset
   polygons_boom
   edge_boom
   polygons_to_edges_mk2
   recalc_normals
   triangulate
   triangulate_heavy
   planar_faces
   edge_split
   split_faces
   vertices_mask
   make_monotone
   planar_edgenet_to_polygons
   inset_faces
   follow_active_quads
   separate_parts_to_indexes
   extrude_multi_alt
   dissolve_mesh_elements
   rigid_origami
   flat_geometry
   edgenet_to_paths
