extrude multi alt
=================

This node wraps **mesh_extra_tools/mesh_extrude_plus**. it's more of a tech demo than any particularly useful node. Look at the code for both and get an idea of how you might be able to adapt code you find out in the wild, and want to nodify it. This node might be a place to start.

.. image:: https://cloud.githubusercontent.com/assets/619340/26636381/e4100362-461c-11e7-887a-abf71657eb8d.png