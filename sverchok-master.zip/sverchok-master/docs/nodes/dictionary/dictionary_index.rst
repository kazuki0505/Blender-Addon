**********
Dictionary
**********

.. toctree::
   :maxdepth: 2

   dictionary_in
   dictionary_out