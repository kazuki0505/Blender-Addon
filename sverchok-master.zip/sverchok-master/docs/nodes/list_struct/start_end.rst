List First & Last
=================

Functionality
-------------

First and last items of data on some level

Inputs
------

**Data** - data to take items

Properties
----------

**level** - leve to take first and last items

Outputs
-------

**Middl** - all between first and last items
**First** - First item
**Last** - Last item

Examples
--------

.. image:: https://cloud.githubusercontent.com/assets/5783432/5603173/c487d550-9387-11e4-8b3e-f45c2250048b.jpg
  :alt: First-Last