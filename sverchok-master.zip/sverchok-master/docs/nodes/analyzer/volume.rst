Volume
======

*Alias: Volume*

Functionality
-------------

Count Volume of every object. Output list of values

Inputs
------

- Vers vertices of object(s)
- Pols polygons of object(s)


Outputs
-------

- Volume, corresponding to count of objects it outputs volumes in list.

Examples
--------

.. image:: https://cloud.githubusercontent.com/assets/5783432/18602915/2ecd75b0-7c7e-11e6-8f7a-ae9a39cfbf52.png