File Path
=========

This node will help gathering one or more file paths from the OS.

It can also select one folder if no files are selected 
