*******
Objects
*******

.. toctree::
   :maxdepth: 2

   get_asset_properties_mk2
   lattice_analyzer
   armature_analyzer
   sample_uv_color
   select_mesh_verts
   weightsmk2
   getsetprop
   getsetprop_mk2
   assign_materials
   material_index
   set_custom_uv_map
   set_loop_normals
