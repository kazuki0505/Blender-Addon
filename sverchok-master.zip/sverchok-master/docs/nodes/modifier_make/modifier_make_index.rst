*************
Modifier Make
*************

.. toctree::
   :maxdepth: 2

   bisect
   cross_section
   cut_object_by_surface
   edges_adaptative
   lathe
   matrix_tube
   pipe_tubes
   adaptive_polygons_mk3
   solidify_mk2
   uv_connect
   wafel
   join_tris
   framework
   wireframe
   offset_line
   bevel_curve
   contour2D
   fractal_curve
   dual_mesh
   diamond_mesh
   clip_verts
   sweep_modulator
   csg_booleanMK2
