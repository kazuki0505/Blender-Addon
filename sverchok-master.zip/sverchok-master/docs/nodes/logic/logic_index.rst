*****
Logic
*****

.. toctree::
   :maxdepth: 2

   logic_node
   neuro_elman
   neuro_elman_ru
   evolver
   genes_holder
   switch_MK2
   input_switch_mod
   custom_switcher
   range_switch
   loop_in
   loop_out
