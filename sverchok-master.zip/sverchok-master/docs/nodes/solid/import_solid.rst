Import Solid
============

Functionality
-------------

Imports Brep files


Examples
--------

.. image:: https://raw.githubusercontent.com/vicdoval/sverchok/docs_images/images_for_docs/solid/import_solid/import_solid_blender_sverchok_example.png
