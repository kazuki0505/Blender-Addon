bl_info = {
    "name": "d_delete_withoutConfirm",
    "author": "Way2Close",
    "description": "Deletes element from msm",
    "category": "3D View"}

import bpy
from bpy.utils import register_class, unregister_class


class Delete_withoutConfirm(bpy.types.Operator):
    """Deletes element from msm"""
    bl_idname = "edit.delete_without_confirm"
    bl_label = "delete_withoutConfirm"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # delete_withoutConfirm

        # get msm
        msm = bpy.context.tool_settings.mesh_select_mode

        # cancel if no active
        if not bpy.context.active_object:
            return {'FINISHED'}

        if bpy.context.active_object.mode == "EDIT":

            if msm[0]:
                # delete verts
                bpy.ops.mesh.delete(type = 'VERT')

            elif msm[1]:
                # delete edges
                bpy.ops.mesh.delete(type = 'EDGE')

            elif msm[2]:
                # delete faces
                bpy.ops.mesh.delete(type = 'FACE')

        return {'FINISHED'}


# Class list to register
_classes = [
    Delete_withoutConfirm
]

def register():
    for cls in _classes:
        register_class(cls)

def unregister():
    for cls in _classes:
        unregister_class(cls)

if __name__ == "__main__":
    register()