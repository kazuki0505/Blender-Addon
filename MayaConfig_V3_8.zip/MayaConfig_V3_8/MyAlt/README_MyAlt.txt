Find out more about MyAlt at
https://www.youtube.com/watch?v=Z8qnOGMMDTw&t=6s