Stay informed of Config/Addon Updates by following FormAffinity on Youtube.

-----------------------------------------
Version 3.8 - Built by Jesse Doyle. Copyright 2021 Jesse Doyle
April 2021
-----------------------------------------

For Version 2.92 Blender Builds
Found at https://builder.blender.org/download/

-----------------------------------------
Install Instructions Video for Blender Builds:
https://youtu.be/i7a8HjV9-kk

(Old install video may be found here https://www.youtube.com/watch?v=ZV6LqlaoQWs)

Install Instructions for Blender 2.92 Full Version
https://youtu.be/eJGliDhBCq8
-----------------------------------------

Maya Full Config includes Layout, Marking Menu, Display Panel, Hotkeys and other features for Blender. See "Install INstructions" for image instructions as well as a link to Video instructions for install.

-----------------------------------------

Special thanks to Sven for content support.
Thanks to testers and coding help:  ReachMatthews, Nittorious, Way2Close, Natetronn
And thanks to all of you for using and supporting the Config!

Thanks for using FormAffinity Content. 


