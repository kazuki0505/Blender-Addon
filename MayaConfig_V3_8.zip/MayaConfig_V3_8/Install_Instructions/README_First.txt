Choose either the jpeg, pdf, text doc or Video install Instructions contained in this folder. 

We recommend the Video install, as it links to a youtube video that walks you through the process.