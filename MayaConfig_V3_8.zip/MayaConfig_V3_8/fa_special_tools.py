

import bpy
from bpy.types import Menu

class SimpleCustomMenu(bpy.types.Menu):
    bl_label = "Special Tools"
    bl_idname = "Special_Tools_Menu"

    def draw(self, context):
        layout = self.layout
        if context.space_data.type == 'VIEW_3D':
            if context.mode == 'EDIT_MESH':

                layout.separator()
                

                # if vertex mode
                if context.tool_settings.mesh_select_mode[:] == (True, False, False):
                    layout.menu("VIEW3D_MT_edit_mesh_vertices", text = "Vertex Special", icon = 'VERTEXSEL')
                    layout.separator()
                    layout.label(text="Mode Switch", icon='DOWNARROW_HLT')
                    layout.operator("object.msm_from_object", text = "Edges", icon = 'EDGESEL').mode = 'edge'
                    layout.operator("object.msm_from_object", text = "Faces", icon = 'FACESEL').mode = 'face'
                    layout.operator("object.mode_set", text = "Object Mode", icon = "OBJECT_DATA")
        
                # if edge mode
                if context.tool_settings.mesh_select_mode[:] == (False, True, False):
                    layout.menu("VIEW3D_MT_edit_mesh_edges", text = "Edge Special", icon = 'EDGESEL')
                    layout.separator()
                    layout.label(text="Mode Switch", icon='DOWNARROW_HLT')
                    layout.operator("object.msm_from_object", text = "Vertices", icon = 'VERTEXSEL').mode = 'vert'
                    layout.operator("object.msm_from_object", text = "Faces", icon = 'FACESEL').mode = 'face'
                    layout.operator("object.mode_set", text = "Object Mode", icon = "OBJECT_DATA")
        
                # if face mode
                if bpy.context.tool_settings.mesh_select_mode[:] == (False, False, True):
                    layout.menu("VIEW3D_MT_edit_mesh_faces", text = "Face Special", icon = 'FACESEL')
                    layout.separator()
                    layout.label(text="Mode Switch", icon='DOWNARROW_HLT')
                    layout.operator("object.msm_from_object", text = "Vertices", icon = 'VERTEXSEL').mode = 'vert'
                    layout.operator("object.msm_from_object", text = "Edges", icon = 'EDGESEL').mode = 'edge'
                    layout.operator("object.mode_set", text = "Object Mode", icon = "OBJECT_DATA")

    
                
            elif context.mode == 'OBJECT':
                layout.label("object mode")
        elif context.space_data.type == 'IMAGE_EDITOR':
            layout.label("No Context! image editor")
        else:

            layout.label("No Context!")
                

def register():
    bpy.utils.register_class(SimpleCustomMenu)
  
    
def unregister():
    bpy.utils.unregister_class(SimpleCustomMenu)

if __name__ == "__main__":
    register()
